from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session
from pydantic import BaseModel
from datetime import datetime

from database import SessionLocal
from models import BdPrototipe

app = FastAPI()

# Modelo de entrada
class RegistroRequest(BaseModel):
    num_house: float
    fec_start: datetime
    location_start: str
    location_end: str
    first_application: str
    second_application: str
    third_application: str
    fec_end: datetime

# Conexión a la base
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Endpoint POST
@app.post("/registro")
def guardar_registro(data: RegistroRequest, db: Session = Depends(get_db)):
    nuevo = BdPrototipe(**data.dict())
    db.add(nuevo)
    db.commit()
    db.refresh(nuevo)
    return {"status": "ok", "id": nuevo.id}
